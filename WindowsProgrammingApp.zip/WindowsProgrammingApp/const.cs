﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsProgrammingApp
{
    public class Const
    {
        public const  string INCREASE_FONT_SIZE = "Increase Font Size";
        public const string DECREASE_FONT_SIZE = "Decrease Font Size";
        public const string CHANGE_TEXT_COLOR = "Change Text Color";
        public const string CHANGE_HIGHLIGHT_COLOR= "Change Highlight Color";
        public const string UNDERLINE = "Underline";
        public const string MIDDLELINE = "Middleline";
        public const string BOLD = "Bold";
        public const string ITALICK = "Italick";

    }
}

